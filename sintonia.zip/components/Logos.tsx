import React from 'react';

// SintoniaRuralLogo was removed as it is no longer used in the application.
